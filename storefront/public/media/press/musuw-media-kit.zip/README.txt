Musuw official media kit — 2026-09-19

Website: https://musuw.com/
Actual walkthrough: https://musuw.com/guides/citation-checks
Chinese walkthrough: https://musuw.com/zh/guides/citation-checks
Plans: https://musuw.com/#pricing
Contact: support@didren.com

Use these official assets for coverage of Musuw; retain the product name and attribution.

Actual Cedar recordings: musuw-cedar-live-{en,zh}-16x9.mp4 (40 seconds)
and musuw-cedar-live-{en,zh}-9x16.mp4 (30 seconds).
Chinese product interface, English or Chinese captions, no audio.
Fictional original demo material, not customer data. Waiting periods omitted.
Portrait edits enlarge/crop the original desktop UI; they do not depict a mobile interface.
Playback is 1x. The planned October 1 date remains conditional, not final approval.

The four other 33-second MP4s are edited screenshot showcases, not live recordings.
The standalone product screenshots show a public example workspace.
No asset establishes measured customer outcomes, traffic, accuracy, or time savings.

Includes the logo, public screenshots, eight MP4s and covers, captions,
two one-page product briefs (English and Chinese PDF), and three original
fictional Cedar Markdown source documents.
Musuw is built from WeKnora; see https://github.com/estromeglovettgen-coder/musuw for attribution.
