Musuw public media kit
https://musuw.com/press
Contact: support@didren.com

Musuw is an AI knowledge base with source-cited answers, an AI-assisted Wiki, and a knowledge graph. See current product capabilities and plans at https://musuw.com/.

The four silent 33-second videos are edited feature showcases using public product screenshots and an example document, not live product recordings. English / Chinese titles and captions accompany the English interface. 16:9 videos are 1920x1080; 4:5 videos are 1080x1350. VTT and SRT captions are included.

Use these assets to describe Musuw accurately. Keep the product name and example context intact. Do not imply an endorsement or present the showcase as a live recording.

四个无音轨的 33 秒视频基于公开产品截图与示例文档剪辑，并非实机录屏。视频提供中英文标题和字幕，产品界面为英文。请保留产品名称与示例语境，勿暗示未经确认的背书。
